package com.example.login

import android.content.res.Configuration
import android.os.Bundle
import android.util.Log
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.get
import androidx.navigation.fragment.findNavController
import com.example.login.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

        
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.

        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        if(item.itemId == R.id.DyN){
            Log.d("REGISTRAR", "D&N")
            changeDayNight()
        }else if(item.itemId == R.id.Ayuda){
            val navController = findNavController(R.id.nav_host_fragment_content_main)
            navController.navigate(R.id.action_global_helpFragment)
        }

        return when (item.itemId) {
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun changeDayNight(){
        when (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) {
            Configuration.UI_MODE_NIGHT_NO -> {
                changePreff();AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)}
            Configuration.UI_MODE_NIGHT_YES -> {
                changePreff();AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)}
            else -> {
                Log.d("REGISTRAR", "NO PASA")}
        }
    }

    private fun changePreff(){
        for(User in SecondFragment.usersList){
            if(User.name.toString().uppercase() == HomeFragment.user.uppercase()){
                when (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) {
                    Configuration.UI_MODE_NIGHT_NO -> {
                        Log.d("REGISTRAR", "CHANGE NOCHE");User.preffN = true}
                    Configuration.UI_MODE_NIGHT_YES -> {
                        Log.d("REGISTRAR", "CHANGE DIA");User.preffN = false}
                    else -> {
                        Log.d("REGISTRAR", "NO PASA")}
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }


}