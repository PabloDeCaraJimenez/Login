package com.example.login

import android.os.Bundle
import android.text.TextUtils
import android.util.Patterns
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.widget.addTextChangedListener
import androidx.navigation.NavOptions
import androidx.navigation.fragment.findNavController
import com.example.login.databinding.FragmentFirstBinding


class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        HomeFragment.user = ""

        binding.etEmail.addTextChangedListener {
            binding.tilEmail.error = null
        }
        binding.etPass.addTextChangedListener {
            binding.tilPass.error = null
        }

        binding.etEmail.setOnFocusChangeListener { view, b -> binding.tilEmail.error = null }
        binding.tilEmail.error = null


        binding.btEntrar.setOnClickListener {

            binding.tilEmail.error = null
            binding.tilPass.error = null


            var found : Boolean = false
            for(User in SecondFragment.usersList){
                if(binding.etEmail.text.toString().uppercase() == User.email.toString().uppercase() && binding.etPass.text.toString().uppercase() == User.pass.toString().uppercase()){
                    if(User.preffN){
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                    }else{
                        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                    }
                    HomeFragment.user = User.name
                    findNavController().navigate(R.id.action_FirstFragment_to_homeFragment)
                    found = true
                    break
                }
            }
            if(!found){
                if(!isValidEmail(binding.etEmail.text.toString())){
                    binding.tilEmail.error = "Correo no válido"
                }else if(binding.etPass.text.toString().length < 8){
                    binding.tilPass.error="Introduzca contraseña, min 8 caracteres"
                }else{
                    findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
                }
            }

        }
        binding.btRegistrar.setOnClickListener {
            findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        }
    }

    private fun isValidEmail(target: CharSequence?): Boolean {
        return if (TextUtils.isEmpty(target)) {
            false
        } else {
            Patterns.EMAIL_ADDRESS.matcher(target).matches()
        }
    }

    override fun onStart() {
        super.onStart()

        binding.etEmail.text = null
        binding.etPass.text = null
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }




}