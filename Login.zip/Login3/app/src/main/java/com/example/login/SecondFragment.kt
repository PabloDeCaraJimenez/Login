package com.example.login

import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.util.Patterns
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.login.databinding.FragmentSecondBinding
import com.google.android.material.snackbar.Snackbar


class SecondFragment : Fragment() {

    data class User(
        val name: String,
        val email: String,
        val pass: String,
        var preffN: Boolean
    )
    companion object{
        var usersList: MutableList<User> = mutableListOf(
            User(name="Ana79", email="Ana_Andrade@gmail.com", pass="11111111", preffN = true),
            User(name="Bertito", email="Berto_Borrego@hotmail.com", pass="22222222", preffN = false),
            User(name="KR-La", email="Carla_Cabrera@yahoo.com", pass="33333333", preffN = false),
            User(name="DomD", email="Domingo_Daimiel@ieszaidinvergeles.com", pass="44444444", preffN = false),
            User(name="Esther_TT", email="Esther_Echanove@houtlook.com", pass="55555555", preffN = false)
        )
    }


    private var _binding: FragmentSecondBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentSecondBinding.inflate(inflater, container, false)

        binding.btRegistro.setOnClickListener{
            if (container != null) {
                registrar(container, binding.etNombre?.getText().toString(), binding.etEmail?.getText().toString(), binding.etPass?.getText()
                    .toString(), binding.etPass2?.getText().toString())
            }
        }

        binding.btAtras.setOnClickListener {
            findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
        }

        return binding.root



    }

    private fun registrar(view: View, newName: String, newEmail : String, newPass : String, newPass2 : String){
        Log.d("REGISTRO", newPass)
        Log.d("REGISTRO", newPass2)
        var nameOk : Boolean = true
        var emailOk : Boolean = true
        var passOk : Boolean = false
        binding.tilEMail.error= null
        binding.tilNombre.error = null
        binding.tilPass.error = null
        binding.tilPass2.error = null

        // ______________________________________________________________NAME
        for(User in usersList){
            if(User.name.uppercase() == newName.uppercase()){
                nameOk = false
                binding.tilNombre.error = "El nombre ya está registrado"
                break
            }
        }
        if(newName.length < 3){
            nameOk = false
            binding.tilNombre.error = "El nombre debe tener al menos 3 caracteres"
        }
    // _____________________________________________________________EMAIL
        if(!isValidEmail(newEmail)){
            emailOk = false
            binding.tilEMail.error = "El correo no tiene el formato correcto"
        }else{
            for(User in usersList){
                if(User.email.uppercase() == newEmail.uppercase()){
                    emailOk = false
                    binding.tilEMail.error = "El correo ya está registrado"
                }
            }
        }
    // ______________________________________________________________PASS
        if(newPass.length >= 8 && newPass == newPass2){
            passOk = true
        }else if(newPass.length < 8) {
            binding.tilPass.error = "Mínimo 8 caracteres"
        }else{
            binding.tilPass2.error = "Contraseñas distintas"
        }
    // __________________________________________________________REGISTRO
        if(nameOk && emailOk && passOk){
            usersList.add(User(name=newName, email=newEmail, pass=newPass, preffN = false))
            Snackbar.make(view, "Nuevo usuario registrado", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
            findNavController().navigate(R.id.action_SecondFragment_to_FirstFragment)
        }

    }

    private fun isValidEmail(target: CharSequence?): Boolean {
        return if (TextUtils.isEmpty(target)) {
            false
        } else {
            Patterns.EMAIL_ADDRESS.matcher(target).matches()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.etNombre.addTextChangedListener {
            binding.tilNombre.error = null
        }
        binding.etEmail.addTextChangedListener {
            binding.tilEMail.error = null
        }
        binding.etPass.addTextChangedListener {
            binding.tilPass.error = null
        }
        binding.etPass2.addTextChangedListener {
            binding.tilPass2.error = null
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}